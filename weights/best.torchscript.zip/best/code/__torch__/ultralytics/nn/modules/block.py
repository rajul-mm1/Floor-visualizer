class C2f(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  cv1 : __torch__.ultralytics.nn.modules.conv.___torch_mangle_5.Conv
  cv2 : __torch__.ultralytics.nn.modules.conv.___torch_mangle_8.Conv
  m : __torch__.torch.nn.modules.container.ModuleList
  def forward(self: __torch__.ultralytics.nn.modules.block.C2f,
    argument_1: __torch__.torch.nn.modules.activation.___torch_mangle_203.SiLU,
    argument_2: Tensor) -> Tensor:
    cv2 = self.cv2
    m = self.m
    _0 = getattr(m, "0")
    cv1 = self.cv1
    _1 = (cv1).forward(argument_1, argument_2, )
    _2, input, = torch.chunk(_1, 2, 1)
    _3 = [_2, input, (_0).forward(argument_1, input, )]
    input0 = torch.cat(_3, 1)
    return (cv2).forward(argument_1, input0, )
class Bottleneck(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  cv1 : __torch__.ultralytics.nn.modules.conv.___torch_mangle_11.Conv
  cv2 : __torch__.ultralytics.nn.modules.conv.___torch_mangle_14.Conv
  def forward(self: __torch__.ultralytics.nn.modules.block.Bottleneck,
    argument_1: __torch__.torch.nn.modules.activation.___torch_mangle_203.SiLU,
    input: Tensor) -> Tensor:
    cv2 = self.cv2
    cv1 = self.cv1
    _3 = (cv2).forward(argument_1, (cv1).forward(argument_1, input, ), )
    return torch.add(input, _3)
class SPPF(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  cv1 : __torch__.ultralytics.nn.modules.conv.___torch_mangle_85.Conv
  cv2 : __torch__.ultralytics.nn.modules.conv.___torch_mangle_88.Conv
  m : __torch__.torch.nn.modules.pooling.MaxPool2d
  def forward(self: __torch__.ultralytics.nn.modules.block.SPPF,
    argument_1: __torch__.torch.nn.modules.activation.___torch_mangle_203.SiLU,
    argument_2: Tensor) -> Tensor:
    cv2 = self.cv2
    m = self.m
    cv1 = self.cv1
    _4 = (cv1).forward(argument_1, argument_2, )
    _5 = (m).forward(_4, )
    _6 = (m).forward1(_5, )
    input = torch.cat([_4, _5, _6, (m).forward2(_6, )], 1)
    return (cv2).forward(argument_1, input, )
class DFL(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  conv : __torch__.torch.nn.modules.conv.___torch_mangle_208.Conv2d
  def forward(self: __torch__.ultralytics.nn.modules.block.DFL,
    x: Tensor) -> Tensor:
    conv = self.conv
    b = ops.prim.NumToTensor(torch.size(x, 0))
    _7 = int(b)
    _8 = int(b)
    a = ops.prim.NumToTensor(torch.size(x, 2))
    _9 = int(a)
    _10 = torch.transpose(torch.view(x, [_8, 4, 16, int(a)]), 2, 1)
    input = torch.softmax(_10, 1)
    distance = torch.view((conv).forward(input, ), [_7, 4, _9])
    return distance
